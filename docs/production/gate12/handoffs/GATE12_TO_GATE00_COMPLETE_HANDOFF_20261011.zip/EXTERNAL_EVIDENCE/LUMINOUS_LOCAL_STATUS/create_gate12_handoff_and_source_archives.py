"""Gate12 transferable archives. No source modification; never touch frozen assets.

Small authoritative handoff ZIP is suitable for the Git branch.
The separate PRIVATE binary source backup stays on the user's workstation,
never uploaded to GitHub or redistributed. Requires generous local disk.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,os,pathlib,zipfile,sys
W=pathlib.Path(r"D:\UnrealProjects\OfflineGame_Gate12_Koikatsu_20261010")
P=pathlib.Path(r"D:\Tools\GameAssetPipeline\KoikatsuParty")
S=P/"characters/LUMINOUS_VALENTINE_V3/gate12_fresh_export_20261011"
OUT=W/"docs/production/gate12/handoffs"
LOCAL=W/"Saved/Gate12Koikatsu/LuminousV3"
OUT.mkdir(parents=True,exist_ok=True)
def sha(f):
 h=hashlib.sha256()
 with f.open("rb") as stream:
  for a in iter(lambda:stream.read(4*1024*1024),b""):h.update(a)
 return h.hexdigest()
def add(files,source,archivepath,maxsize=None):
 if not source.is_file():return
 if maxsize is not None and source.stat().st_size>maxsize:return
 archivepath=archivepath.replace("\\","/")
 if archivepath in files and files[archivepath]!=source:raise RuntimeError("Duplicate "+archivepath)
 files[archivepath]=source
def walk(files,root,prefix,allowed=None,maxsize=None):
 if not root.is_dir():return
 for f in root.rglob("*"):
  if f.is_file() and (allowed is None or f.suffix.lower() in allowed):
   add(files,f,prefix+"/"+f.relative_to(root).as_posix(),maxsize)
def handoff():
 files={}
 walk(files,W/"docs/production/gate12","docs/production/gate12",
   {".md",".json",".txt",".patch",".ps1",".py",".yaml",".yml",".ini",".xml",".csv"},6_000_000)
 walk(files,W/"Scripts/Gate12Koikatsu","Scripts/Gate12Koikatsu",
   {".py",".ps1",".md",".json",".txt",".cfg",".ini"},2_000_000)
 walk(files,W/"SourceAssets/Gate12/MotionV3/CMU","SourceAssets/Gate12/MotionV3/CMU",None,3_000_000)
 walk(files,W/"Content/Experimental/Gate12Koikatsu/Animation/NativeMocapV3",
   "Content/Experimental/Gate12Koikatsu/Animation/NativeMocapV3",{".uasset"},2_000_000)
 walk(files,LOCAL,"EXTERNAL_EVIDENCE/LUMINOUS_LOCAL_STATUS",
   {".json",".md",".txt",".patch",".ps1",".py"},3_000_000)
 walk(files,S/"ANIMATION_REUSE","EXTERNAL_EVIDENCE/ORIGINAL_KOIKATSU_ANIMATION_REUSE",
   {".json",".txt",".md"},3_000_000)
 for f in S.glob("*.json"):
  add(files,f,"EXTERNAL_EVIDENCE/LUMINOUS_PMS/"+f.name,maxsize=3_000_000)
 for st in ("CLOTHED","UNDERWEAR","NUDE"):
  folder=S/"BLENDER_FRESH"/st
  for f in folder.glob("*.json"):
   add(files,f,"EXTERNAL_EVIDENCE/LUMINOUS_BLENDER/"+st+"/"+f.name,maxsize=3_000_000)
  for f in (S/"SEALED_INPUTS").glob("*.json"):
   add(files,f,"EXTERNAL_EVIDENCE/PRIMARY_PARTY_CARD_METADATA/"+f.name,maxsize=3_000_000)
  rec=S/("FRESH_EXPORT_"+st+"_RECEIPT.json")
  add(files,rec,"EXTERNAL_EVIDENCE/PRIMARY_PARTY_EXPORT_RECEIPTS/"+rec.name,maxsize=3_000_000)
  manifest=LOCAL/"LosslessSources"/("LuminousV3"+st)/"shards/manifest_full_fidelity_primitives.json"
  add(files,manifest,"EXTERNAL_EVIDENCE/LUMINOUS_NATIVE_SOURCE_SHARD_MANIFEST/"+st+".json",maxsize=3_000_000)
 # Save exact UNBUILT native source for reference, without pretending it compiles.
 for f in (W/"Source/OfflineGame/Public/Koikatsu/OGKoikatsuPlayableCharacter.h",
           W/"Source/OfflineGame/Private/Koikatsu/OGKoikatsuPlayableCharacter.cpp"):
  add(files,f,"UNBUILT_CONTROLLER_SOURCE_SNAPSHOT/"+f.name,maxsize=3_000_000)
 # Preserve the previous attached reconstruction instructions where available from shared handoffs.
 base=P/"handoffs"
 for f in base.glob("*LUMINOUS*HANDOFF*.txt"):
  add(files,f,"EXTERNAL_EVIDENCE/GATE01_TO_GATE00/"+f.name,maxsize=3_000_000)
 note="""# GATE 12 TO GATE 00 - READ FIRST (2026-10-11)

THIS ZIP contains the exact authoritative current handoff, the SHA worktree
manifest, original working scripts and focused JSON evidence. It is not
a source-binary ZIP and is not a playable Android APK.

READ IN ORDER
1. docs/production/gate12/GATE12_LUMINOUS_V3_AUTHORITATIVE_CONTINUATION_HANDOFF_20261011.md
2. docs/production/gate12/GATE12_PROVEN_IMPORT_AND_MOTION_DIAGNOSIS_SUPPLEMENT_20261011.md
3. docs/production/gate12/evidence/luminous-v3-continuation-20261011/GATE12_LUMINOUS_V3_SOURCE_AND_WORKTREE_MANIFEST.json
4. docs/production/gate12/KOIKATSU_NONANIMATION_PIPELINE_FROZEN_V1_20261011.md
5. docs/production/gate12/MOTION_V2_REJECTED_ANATOMICAL_RIG_AUDIT_20261011.md
6. docs/production/gate12/MOTION_V3_RESEARCH_AND_IMPLEMENTATION_CONTRACT_20261011.md
7. docs/production/gate12/MOTION_V3_REAL_ARTICULATION_STAGE1_20261011.md

Remote workstation LAPTOP-1LI4VRCJ:
- Unreal worktree D:\\UnrealProjects\\OfflineGame_Gate12_Koikatsu_20261010
- Frozen Foundation D:\\UnrealProjects\\Offline-Game
- Luminous sources D:\\Tools\\GameAssetPipeline\\KoikatsuParty\\characters\\LUMINOUS_VALENTINE_V3\\gate12_fresh_export_20261011
- Existing native UE content: Content\\Experimental\\LuminousValentineV3
- Native import journals: Saved\\Gate12Koikatsu\\LuminousV3
- Branch production/gate12-koikatsu-ue583-fixture-20261010

Current real Luminous milestone: 3 verified original Party state exports and
Blender source GLBs; CLOTHED 17 of 45 native skeletal parts actually imported
(15 morph PASS, 2 with meaningful morph omissions). UNDERWEAR/NUDE native
parts not imported; no new Luminous APK; not installed on S26. First fixture
success is NOT Luminous integration success.

Previously proven general first Koikatsu test-character method:
genuine high-quality skinned GLB -> lossless hash-checked primitive shards
-> real UE5.8.3 native skeletal/texture/morph import -> project-owned mobile
morph shaders -> existing native gameplay-based character and QA map
-> Android ARM64/ASTC native cook -> isolated signed APK -> actual S26 play.
First fixture animation FAILED user aesthetic/anatomical acceptance despite
successful on-device geometry/gameplay proof. Source method is frozen only
for proven non-animation aspects. Read detailed addendum.

Original animation diagnosis: move input is correct +UE X/Y; controller
used only horizontal velocity magnitude and wrong visual facing, procedural
bone-local Y rotations twisted bones axially instead of bending knee/elbow,
flight fell through to ground gait, synthetic sine motions lacked proper
stance/swing, planted feet and differentiated joint articulation. V3 CMU
three real clips cold load PASS on ONE skeleton; entire-game and phone
animation quality remains NOT TESTED. Installed Unity Koikatsu/Studio
original AnimationClips were discovered but not yet baked to UE.

Do not alter ten frozen source SHA files, original game package, save DB,
Foundation commit 3f54f07cacbf193e160d0be15a7be5a7bc730c3b
or draft/unmerged PR #16. Gate11 ARTIFACT_READY is NOT granted.

BINARY ASSET TRANSFER: source cards, original Koikatsu PMX+texture directories,
full editable Blender .blend/.fbx/.glb, 121 full-quality source GLB shards and
80 partial Luminous .uasset files are on the connected laptop and are NOT
in this Git-distributable small ZIP. Access that laptop directly (preferred)
or use the separately generated PRIVATE binary backup ZIP. The JSON manifest
lists those originals and hashes but cannot reconstruct files without bytes.
"""
 name="GATE12_TO_GATE00_COMPLETE_HANDOFF_20261011.zip"
 dest=OUT/name
 manifest={"schema":"GATE12_CROSS_CONVERSATION_HANDOFF_PACKAGE_1",
   "authoritative_source_worktree":"production/gate12-koikatsu-ue583-fixture-20261010",
   "includes_original_private_character_binaries":False,
   "original_private_binaries_kept_on_workstation":True,
   "attached_gameplay_android_apk":False,"files":[]}
 # Build manifest of exact raw bytes
 for arc,p in sorted(files.items()):
  manifest["files"].append({"path":arc,"bytes":p.stat().st_size,"sha256":sha(p)})
 payloads={"GATE00_READ_FIRST.md":note.encode("utf-8"),
           "GATE12_BUNDLED_FILE_SHA256_MANIFEST.json":(json.dumps(manifest,indent=2)+"\n").encode()}
 with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
  for arc,data in payloads.items():z.writestr(arc,data)
  for arc,p in sorted(files.items()):z.write(p,arc)
 with zipfile.ZipFile(dest,"r") as z:
  assert z.testzip() is None
  for d in manifest["files"]:
   assert hashlib.sha256(z.read(d["path"])).hexdigest()==d["sha256"]
 print(json.dumps({"status":"PASS_HANDOFF_ZIP_WITH_RECHECKED_ALL_SHA",
    "zip":str(dest),"size_bytes":dest.stat().st_size,
    "SHA256":sha(dest),"files":len(files)+len(payloads)},indent=2))
def private():
 # This is a separate, potentially large private archive retained on the
 # user's own laptop. Never stage or push this path into Git.
 dest=P/"handoffs/GATE12_LUMINOUS_V3_PRIVATE_BINARY_SOURCE_AND_NATIVE_20261011.zip"
 files={}
 walk(files,S/"SEALED_INPUTS","LUMINOUS_ORIGINAL_PARTY/SEALED_INPUTS",None)
 walk(files,S/"FRESH_PARTY_EXPORTS","LUMINOUS_ORIGINAL_PARTY/FRESH_PARTY_EXPORTS",None)
 walk(files,S/"BLENDER_FRESH","LUMINOUS_PRIMARY_EDITABLE_BLENDER_FBX_GLB",None)
 walk(files,LOCAL/"LosslessSources","LUMINOUS_LOSSLESS_NATIVE_IMPORT_SOURCE_SHARDS",None)
 walk(files,W/"Content/Experimental/LuminousValentineV3","LUMINOUS_PARTIAL_NATIVE_UNREAL_UASSETS",None)
 walk(files,LOCAL,"LUMINOUS_IMPORT_JOURNALS",
     {".json",".md",".txt",".patch",".ps1",".py"},None)
 walk(files,S/"ANIMATION_REUSE","ORIGINAL_GAME_ANIMATION_RESEARCH",None)
 manifest={"schema":"G12_PRIVATE_BINARY_SOURCE_ARCHIVE_1","private_source":True,
    "distributable_to_public_repository":False,"files":[]}
 # Don't recalculate giant hash per file twice. Verify source before writing.
 with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=2,allowZip64=True) as z:
  for i,(arc,p) in enumerate(sorted(files.items())):
   z.write(p,arc)
   manifest["files"].append({"path":arc,"sha256":sha(p),"bytes":p.stat().st_size})
   if i%100==0:print("PRIVATE_BACKUP_PROGRESS",i,"/",len(files),flush=True)
  z.writestr("SOURCE_ASSET_BINARY_SHA256_MANIFEST.json",json.dumps(manifest,indent=2)+"\n")
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None
 print(json.dumps({"status":"PASS_PRIVATE_SOURCE_ZIP","path":str(dest),
   "files":len(files),"bytes":dest.stat().st_size,"sha256":sha(dest)},indent=2))
if __name__=="__main__":
 ap=argparse.ArgumentParser();ap.add_argument("mode",choices=("handoff","private"));args=ap.parse_args()
 handoff() if args.mode=="handoff" else private()
