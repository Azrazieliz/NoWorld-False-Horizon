$ErrorActionPreference='Stop'
$w='D:\UnrealProjects\OfflineGame_Gate12_Koikatsu_20261010'
$qa="$w\Saved\Gate12Koikatsu\LuminousV3\CLOTHED"
$script="$w\Scripts\Gate12Koikatsu\run_luminous_v3_native_shard_batch_guarded.ps1"
foreach($start in @(8,16,24,32,40)){
 $count=[math]::Min(8,45-$start)
 $path="$qa\native_shards_$('{0:000}' -f $start)_count$('{0:00}' -f $count)_ue583.json"
 if(Test-Path $path){
  $j=Get-Content $path -Raw|ConvertFrom-Json
  if($j.status -notin @('PASS_THIS_BATCH_NATIVE_UE_SOURCE_AND_MORPHS','PARTIAL_NATIVE_SKELETAL_SOURCE_WITH_EXPRESSION_DIFFERENCES_NOT_PRODUCTION_ACCEPTED')){
    throw "Unsafe existing failed batch $start"
  }
  Write-Output "ALREADY_NATIVE_IMPORTED_BATCH=$start"
  continue
 }
 Write-Output "BEGIN_IMPORT_CLOTHED_NEXT=$start COUNT=$count"
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script -State CLOTHED -StartIndex $start -Count $count -MaxSeconds 500
 if($LASTEXITCODE){throw "Native batch blocked $start exit=$LASTEXITCODE"}
 $j=Get-Content $path -Raw|ConvertFrom-Json
 if($j.status -notin @('PASS_THIS_BATCH_NATIVE_UE_SOURCE_AND_MORPHS','PARTIAL_NATIVE_SKELETAL_SOURCE_WITH_EXPRESSION_DIFFERENCES_NOT_PRODUCTION_ACCEPTED')){
  throw "Native asset receipt invalid $start"
 }
 Write-Output "CLOTHED_DONE=$start STATUS=$($j.status) MISSING_EFFECTIVE_MORPHS=$($j.total_effective_morphs_not_imported)"
}
$accepted=@{}
foreach($file in Get-ChildItem $qa -File -Filter 'native_shards_*_ue583.json'){
 $j=Get-Content $file.FullName -Raw|ConvertFrom-Json
 foreach($p in $j.native_parts){
  $index=[int]$p.index
  if($accepted.ContainsKey($index)){throw "Duplicate index $index"}
  if($p.ue_skeletal_mesh_count -lt 1){throw "No native skeletal mesh on $index"}
  $accepted[$index]=[pscustomobject]@{status=$p.status;missing=if($p.effective_morphs_not_imported){[int]$p.effective_morphs_not_imported}elseif($p.source_nonzero_position_morphs){[math]::Max(0,[int]$p.source_nonzero_position_morphs-[int]$p.ue_total_native_morph_targets)}else{0}}
 }
}
if($accepted.Count -ne 45){throw "Native part inventory incomplete $($accepted.Count)/45"}
$deficit=($accepted.Values|Measure-Object -Property missing -Sum).Sum
$report=[ordered]@{status=if($deficit -gt 0){'PARTIAL_ALL_45_NATIVE_MESHES_MORPH_DEFICITS_REMAIN'}else{'PASS_ALL_45_NATIVE_MESHES_AND_EFFECTIVE_MORPHS'};
  state='CLOTHED';parts=45;source_morph_placeholders=5556;native_morphs_missing=$deficit;
  visual_appearance='NOT_TESTED';playable_blueprint='NOT_CREATED';device_test='NOT_TESTED';
  gate11_artifact_ready=$false;timestamp_utc=[DateTime]::UtcNow.ToString('o')}
$report|ConvertTo-Json -Depth 5|Set-Content "$qa\clothed_all_45_native_assembly_readiness.json" -Encoding UTF8
Write-Output "CLOTHED_NATIVE_COMPLETE_45_WITH_QUALITY=$($report.status) MISSING=$deficit"
