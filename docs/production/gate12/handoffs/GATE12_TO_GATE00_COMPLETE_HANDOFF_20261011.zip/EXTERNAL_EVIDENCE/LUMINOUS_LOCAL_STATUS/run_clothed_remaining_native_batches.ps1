$ErrorActionPreference='Stop'
$w='D:\UnrealProjects\OfflineGame_Gate12_Koikatsu_20261010'
$script="$w\Scripts\Gate12Koikatsu\run_luminous_v3_native_shard_batch_guarded.ps1"
$dir="$w\Saved\Gate12Koikatsu\LuminousV3\CLOTHED"
for($start=5;$start -lt 45;$start+=8){
 $count=[math]::Min(8,45-$start)
 $receipt="$dir\native_shards_$('{0:000}' -f $start)_count$('{0:00}' -f $count)_ue583.json"
 if(Test-Path $receipt){
  $old=Get-Content $receipt -Raw|ConvertFrom-Json
  if($old.status -ne 'PASS_THIS_BATCH_NATIVE_UE_SOURCE_AND_MORPHS'){throw "Previously failed batch $start; no overwrite"}
  Write-Output "ALREADY_VALIDATED_CLOTHED_BATCH_START=$start"
  continue
 }
 Write-Output "BEGIN_LUMINOUS_CLOTHED_BATCH=$start COUNT=$count"
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script -State CLOTHED -StartIndex $start -Count $count -MaxSeconds 500
 if($LASTEXITCODE){throw "CLOTHED BATCH $start FAILED GUARD OR VALIDATION (exit $LASTEXITCODE)"}
 $j=Get-Content $receipt -Raw|ConvertFrom-Json
 if($j.status -ne 'PASS_THIS_BATCH_NATIVE_UE_SOURCE_AND_MORPHS' -or @($j.native_parts).Count -ne $count){throw "CLOTHED batch $start invalid"}
 Write-Output "CLOTHED_IMPORT_BATCH_COMPLETED=$start COUNT=$count"
}
$all=@(Get-ChildItem $dir -Filter 'native_shards_*_ue583.json' -File)
$nums=[System.Collections.Generic.HashSet[int]]::new()
foreach($file in $all){$j=Get-Content $file.FullName -Raw|ConvertFrom-Json;if($j.status -ne 'PASS_THIS_BATCH_NATIVE_UE_SOURCE_AND_MORPHS'){throw "Invalid batch $($file.Name)"};foreach($part in $j.native_parts){if(!$nums.Add([int]$part.index)){throw 'Duplicate native shard accepted'}}}
if($nums.Count -ne 45){throw "CLOTHED not complete: $($nums.Count)/45"}
Write-Output 'G12_LUMINOUS_CLOTHED_ALL_45_UE_SKELETAL_MORPH_PARTS_IMPORTED_PASS'
